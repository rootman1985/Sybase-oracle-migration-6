@echo off
mvn clean package
if errorlevel 1 exit /b 1
java -cp "target\sybase-oracle-migrator-1.0.0.jar;lib\jconn4.jar" fr.migration.MigrationApplication MIGRATE
